# Pruning-and-Refactoring-Tool

The project folder is necessary to run the tool.